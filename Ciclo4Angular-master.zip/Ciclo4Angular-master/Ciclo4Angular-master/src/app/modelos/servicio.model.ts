export class EncomiendaModelo{
    id?: String;
    origen?: String;
    destino?: string;
    fecha?: Date;
    hora?: string;
    encomienda?: string;
    valor?: string;
  }


