export class EncomiendaModelo{
    id?: String;
    descripcion?: String;
    peso?: string;
    tipo?: string;
    presentacion?: string;
  }
  