export class ClienteModelo{
  id?: String;
  cedula?: String;
  nombre?: string;
  apellidos?: string;
  pais?: string;
  departamento?: string;
  ciudad?: string;
  direccion?: string;
  telefono?: string;
  correo?: string;
}
